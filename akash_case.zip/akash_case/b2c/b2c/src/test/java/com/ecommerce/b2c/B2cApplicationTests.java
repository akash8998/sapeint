package com.ecommerce.b2c;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssg.bootbatch.entity.Person;
import com.ssg.bootbatch.service.PersonService;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class B2cApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	private PersonService pService;
	
	@Test
	void verifyBrand()
	{
		System.out.println("inside Brand");
		/*
		 * List<Person> pservice=pService.findByFirstName("reebok");
		 * assertEquals(1,pservice.size());
		 */
	}

}
