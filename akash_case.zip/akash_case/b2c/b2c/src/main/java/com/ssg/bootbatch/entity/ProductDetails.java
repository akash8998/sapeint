package com.ssg.bootbatch.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T_PRODUCT_DETAILS")
public class ProductDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;
	
	@Column(name = "brand", nullable = false)
	private String brand;

	@Column(name = "color", nullable = false)
	private String color;
	
	

	@Column(name = "size", nullable = false)
	private String size;
	
	
	

	@Column(name = "sku", nullable = false)
	private String sku;
	
	

	@Column(name = "quantity", nullable = false)
	private int quantity;
	
	public ProductDetails(){
		
	}
	
	public ProductDetails(String brand, String color ,String size,String sku ,int quantity)
	{
		this.brand = brand;
		this.color = color;
		this.size=size;
		this.sku=sku;
		this.quantity=quantity;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


}
