package com.ssg.bootbatch.service;

import java.util.List;

import com.ssg.bootbatch.entity.Person;

public interface PersonService {
	
	List<Person> findAllPeople();
	List<Person> findByFirstName(String firstName);

}
