package com.ssg.bootbatch.service;

import java.util.List;

import com.ssg.bootbatch.entity.ProductDetails;

public interface ProductService {
	
	List<ProductDetails> findAll();
	List<ProductDetails> findByBrand(String brand);
	List<ProductDetails> findByColor(String color);
	List<ProductDetails> findBySize(String size);
	List<ProductDetails> findBySku(String sku);
	//List<ProductDetails> findQuantity(String squantity);

}
