package com.ssg.bootbatch.configuration;

import org.springframework.batch.item.ItemProcessor;

import com.ssg.bootbatch.entity.Person;

public class PersonProcessor implements ItemProcessor<Person,Person> {

	@Override
	public Person process(Person csvBasedPerson) throws Exception {
		Person transformedPerson = new Person(csvBasedPerson.getFirstName(), csvBasedPerson.getLastName());
		return transformedPerson;
	}

}
