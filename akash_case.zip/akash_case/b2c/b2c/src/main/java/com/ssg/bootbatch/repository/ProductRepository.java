package com.ssg.bootbatch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ssg.bootbatch.entity.Person;
import com.ssg.bootbatch.entity.ProductDetails;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository("ProductRepository")
public interface ProductRepository extends JpaRepository<ProductDetails, Long> {
	
	//List<Person> findByFirstName(String firstName);
//	@Query("select c from City c where c.name like"+" %?1")
	  @Query("SELECT u FROM ProductDetails u WHERE u.brand = ?1")
	List<ProductDetails> findByBrandR(String brand);
	  @Query("SELECT u FROM ProductDetails u WHERE u.color = ?1")
	List<ProductDetails> findByColorR(String color);
	  @Query("SELECT u FROM ProductDetails u WHERE u.size = ?1")
	List<ProductDetails> findBySizeR(String size);
	  @Query("SELECT u FROM ProductDetails u WHERE u.sku = ?1")
	List<ProductDetails> findBySkuR(String sku);
}
