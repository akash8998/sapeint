package com.ssg.bootbatch.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssg.bootbatch.entity.ProductDetails;
import com.ssg.bootbatch.repository.ProductRepository;
import com.ssg.bootbatch.service.ProductService;

@Service("ProductsServiceImpl")
public class ProductsServiceImpl implements ProductService {

	  @Autowired
	    ProductRepository repository;
	    
	//  @Autowired
	 // JdbcTemplate jdbcTemplate;

        @Transactional
	    public List<ProductDetails> findByBrand(String brand)
	    {
	        List<ProductDetails> productDetailsList = repository.findByBrandR(brand);
	         
	        if(productDetailsList.size() > 0) {
	            return productDetailsList;
	        } else {
	            return new ArrayList<ProductDetails>();
	        }
	    }
	    

        @Transactional
	    public List<ProductDetails> findByColor(String color)
	    {
	        List<ProductDetails> productDetailsList = repository.findByColorR(color);
	         
	        if(productDetailsList.size() > 0) {
	            return productDetailsList;
	        } else {
	            return new ArrayList<ProductDetails>();
	        }
	    }
	    
	  
        @Transactional
	    public List<ProductDetails> findBySize(String size)
	    {
	        List<ProductDetails> productDetailsList = repository.findBySizeR(size);
	         
	        if(productDetailsList.size() > 0) {
	            return productDetailsList;
	        } else {
	            return new ArrayList<ProductDetails>();
	        }
	    }
	    
	
        @Transactional
	    public List<ProductDetails> findBySku(String sku)
	    {
	        List<ProductDetails> productDetailsList = repository.findBySkuR(sku);
	         
	        if(productDetailsList.size() > 0) {
	            return productDetailsList;
	        } else {
	            return new ArrayList<ProductDetails>();
	        }
	    }
	    
	

		@Override

       @Transactional
		public List<ProductDetails> findAll() {
			// TODO Auto-generated method stub
			return null;
		}
	    
	    
	    

}
