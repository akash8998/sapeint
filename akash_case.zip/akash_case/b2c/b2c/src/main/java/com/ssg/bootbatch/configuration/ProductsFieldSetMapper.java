package com.ssg.bootbatch.configuration;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;

import com.ssg.bootbatch.entity.ProductDetails;

/**
 * This is the PersonFieldSetMapper, which takes each line from csv
 * The input record is then mapped to a Person object
 * @author 810061
 *
 */
@Component
public class ProductsFieldSetMapper implements FieldSetMapper<ProductDetails> {

	@Override
	public ProductDetails mapFieldSet(FieldSet fieldSet) throws BindException {
		ProductDetails productDetails = new ProductDetails();
		productDetails.setBrand(fieldSet.readString("brand"));
		productDetails.setColor(fieldSet.readString("color"));
		productDetails.setSize(fieldSet.readString("size"));
		productDetails.setSku(fieldSet.readString("sku"));
		productDetails.setQuantity(Integer.parseInt(fieldSet.readString("quantity")));
		return productDetails;
	}

}
