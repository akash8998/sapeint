package com.ssg.bootbatch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssg.bootbatch.entity.ProductDetails;
import com.ssg.bootbatch.service.PersonService;
import com.ssg.bootbatch.service.ProductService;

@RestController
public class SearchController {
	
	@Autowired
	private ProductService pDetails;
	
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = "text/plain")
	public String getDefault(){
		return "I am UP!!!";
	}
	
	
	// Brand Search
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data/{Brand}", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findByBrand(@PathVariable("Brand") String Brand){
		System.out.println(" inside brand");
		
		return new ResponseEntity(pDetails.findByBrand(Brand), HttpStatus.OK);
	}
	
	// Size
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data/size/{size}", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findBySize(@PathVariable("size") String size){
		return new ResponseEntity(pDetails.findBySize(size), HttpStatus.OK);
	}
	
	
	//color
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data/color/{color}", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findByColor(@PathVariable("color") String color){
		return new ResponseEntity(pDetails.findByColor(color), HttpStatus.OK);
	}
	
	
	//sku
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data/sku/{sku}", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findBySku(@PathVariable("sku") String sku){
		return new ResponseEntity(pDetails.findBySku(sku), HttpStatus.OK);
	}
	
	//quantity
/*	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data/{squantity}", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findQuantity(@PathVariable("firstName") String squantity){
		return new ResponseEntity(pDetails.findQuantity(squantity), HttpStatus.OK);*/
	//}
	
}
