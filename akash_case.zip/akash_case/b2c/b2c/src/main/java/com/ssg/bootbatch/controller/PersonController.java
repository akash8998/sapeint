package com.ssg.bootbatch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssg.bootbatch.service.PersonService;

@RestController
public class PersonController {
	
	@Autowired
	private PersonService pService;
	
	@RequestMapping(value = "/person", method = RequestMethod.GET, produces = "text/plain")
	public String getDefault(){
		return "I am UP!!!";
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/data", method = RequestMethod.GET, produces ="application/json")
	public ResponseEntity<Object> findAll(){
		return new ResponseEntity(pService.findAllPeople(), HttpStatus.OK);
	}
	
	/*
	 * @SuppressWarnings({ "rawtypes", "unchecked" })
	 * 
	 * @RequestMapping(value = "/data/{firstName}", method = RequestMethod.GET,
	 * produces ="application/json") public ResponseEntity<Object>
	 * findByFirstName(@PathVariable("firstName") String firstName){ return new
	 * ResponseEntity(pService.findByFirstName(firstName), HttpStatus.OK); }
	 */
}
