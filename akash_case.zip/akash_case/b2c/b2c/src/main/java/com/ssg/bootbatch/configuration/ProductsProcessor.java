package com.ssg.bootbatch.configuration;

import org.springframework.batch.item.ItemProcessor;

import com.ssg.bootbatch.entity.ProductDetails;

public class ProductsProcessor implements ItemProcessor<ProductDetails,ProductDetails> {

	@Override
	public ProductDetails process(ProductDetails csvBasedProducts) throws Exception {
		ProductDetails transformedProducts = new ProductDetails(csvBasedProducts.getBrand(), csvBasedProducts.getColor(),csvBasedProducts.getSize(),csvBasedProducts.getSku(),csvBasedProducts.getQuantity());
		return transformedProducts;
	}

}
