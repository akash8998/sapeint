

package com.ssg.bootbatch.configuration;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;

import com.ssg.bootbatch.entity.ProductDetails;

@Configuration
@EnableBatchProcessing
public class BatchConfigurationProducts {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	
	@Bean
	public FlatFileItemReader<ProductDetails> reader() {
		return new FlatFileItemReaderBuilder<ProductDetails>()
				   .name("productItemReader")
				   .resource(new ClassPathResource("products.csv"))
				   .delimited()
				   .names(new String[]{"brand", "color","size","sku","quantity"})
				   .lineMapper(getLineMapper())
				   .fieldSetMapper(new BeanWrapperFieldSetMapper<ProductDetails>(){{
					   setTargetType(ProductDetails.class);
				   }}).build();
	}

	@Bean
	public LineMapper<ProductDetails> getLineMapper() {
		DefaultLineMapper<ProductDetails> defaultLineMapper = new DefaultLineMapper<ProductDetails>();
		
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(";");
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames(new String[] {"brand", "color","size","sku","quantity"});
		
		ProductsFieldSetMapper productsFieldSetMapper = new ProductsFieldSetMapper();
		
		defaultLineMapper.setFieldSetMapper(productsFieldSetMapper);
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		
		return defaultLineMapper;
	}
	
	@Bean
	public ProductsProcessor processor(){
		return new ProductsProcessor();
	}
	
	@Scheduled(cron = "0 */120 * * * ?")
	@Bean
	public JdbcBatchItemWriter<ProductDetails> writer(DataSource dataSource){
		return new JdbcBatchItemWriterBuilder<ProductDetails>()
				   .itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				   .sql("INSERT into T_PRODUCT_DETAILS (brand, color,size,sku,quantity) values (:brand, :color,:size,:sku,:quantity)")
				   .dataSource(dataSource).build();
	}
	
	@Bean
	public Step step1(JdbcBatchItemWriter<ProductDetails> writer){
		return stepBuilderFactory.get("step1")
				.<ProductDetails, ProductDetails> chunk(10)
				.reader(reader())
				.processor(processor())
				.writer(writer).build();
	}
	
	@Bean
	public Job importPersonJob(NotificationListener listener, Step step1){
		return jobBuilderFactory.get("importPersonJob")
								.incrementer(new RunIdIncrementer())
								.listener(listener)
								.flow(step1)
								.end()
								.build();
	}
}
