package com.ssg.bootbatch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssg.bootbatch.entity.Person;
import com.ssg.bootbatch.repository.PersonRepository;
import com.ssg.bootbatch.service.PersonService;

@Service("personService")
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonRepository personRepository;
	
	@Override
	public List<Person> findAllPeople() {
		return personRepository.findAll();
	}

	@Override
	public List<Person> findByFirstName(String firstName) {
		return personRepository.findByFirstName(firstName);
	}

}
